#!/usr/bin/env python
# encoding: utf-8

CONFIG = {
    "development_mode": True,
    "test": {
        # Test that we can use a config defined in default config
        "my_dir": "{project_root}"
    },
}
