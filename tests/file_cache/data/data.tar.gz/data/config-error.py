#!/usr/bin/env python
# -*- coding: utf-8 -*-

# It has no CONFIG variable
