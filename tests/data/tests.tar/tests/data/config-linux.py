#!/usr/bin/env python
# encoding: utf-8

CONFIG = dict(
    linux_only="linux",
    log_dir="./linux_log",
)
