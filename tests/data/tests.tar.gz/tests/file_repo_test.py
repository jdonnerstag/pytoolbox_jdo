#!/usr/bin/env python
# -*- coding: utf-8 -*-

# pylint: disable=missing-function-docstring, missing-module-docstring

from pathlib import Path

import pytest

from toolbox.file_repo import FileRepo
from toolbox.file_matcher.gz_matcher import GzFileMatcher


def test_constructor():
    repo = FileRepo(cache_dir=FileRepo.default_tempdir())
    assert repo.cache_dir and repo.cache_dir.is_dir()

    repo = FileRepo(cache_dir=None)
    assert repo.cache_dir is None

def test_gz_no_cache_dir():
    repo = FileRepo(cache_dir=None)
    repo.register(GzFileMatcher("gz", repo.cache_dir))

    file = "./tests/data/compress_test_file.txt"
    with repo.open(file + ".gz", mode="rt", encoding="utf-8") as fd1:
        with open(file, mode="rt", encoding="utf-8") as fd2:
            assert fd1.read() == fd2.read()


def test_gz_with_cache_dir():
    repo = FileRepo(cache_dir=FileRepo.default_tempdir())
    repo.register(GzFileMatcher("gz", repo.cache_dir))

    repo.clear_cache()
    file = "./tests/data/compress_test_file.txt"
    with repo.open(file + ".gz", mode="rt", encoding="utf-8") as fd1:
        with open(file, mode="rt", encoding="utf-8") as fd2:
            assert fd1.read() == fd2.read()
            fspath = getattr(fd1, "fspath", None)
            assert fspath
            assert Path(file).name == fspath.name
            assert repo.cache_dir
            assert repo.cache_dir.samefile(fspath.parent)

    # Opening it the 2nd time, should give me the cached one
    with repo.open(file + ".gz", mode="rt", encoding="utf-8") as fd1:
        with open(file, mode="rt", encoding="utf-8") as fd2:
            assert fd1.read() == fd2.read()
            fspath = getattr(fd1, "fspath", None)
            assert fspath
            assert Path(file).name == fspath.name
            assert repo.cache_dir
            assert repo.cache_dir.samefile(fspath.parent)
