#!/usr/bin/env python
# encoding: utf-8

CONFIG = {
    "test": {
        # Test that we can use a config defined in default config
        "my_dir": "{project_root}"
    },
}
